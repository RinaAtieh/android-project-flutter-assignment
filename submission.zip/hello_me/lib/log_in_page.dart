import 'package:english_words/english_words.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hello_me/profile_view.dart';
import 'package:hello_me/user_auth.dart';
import 'package:provider/provider.dart';


FirebaseAuth auth = FirebaseAuth.instance;
int succ=0;

class LoginPage extends StatefulWidget {
  final Set<WordPair> saved ;
  LoginPage({Key key, @required this.saved}) : super(key: key);

  @override
  loginScreen createState() => loginScreen();
}

class loginScreen extends State<LoginPage>{

  TextEditingController _email;
  TextEditingController _password;
  static final _formKey = new GlobalKey<FormState>();
  final _key = GlobalKey<ScaffoldState>();

  //final form = _formKey.currentState;

  @override
  void initState() {
    super.initState();
    _email = TextEditingController(text: "");
    _password = TextEditingController(text: "");
  }


  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserRepository>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
        centerTitle: true,
        backgroundColor: Colors.red,
      ),
      body: Builder(
          builder: (context) =>
              Padding(
                padding: EdgeInsets.all(10),
                child: ListView(
                    children: <Widget>[
                      Container(
                          padding: EdgeInsets.all(10),
                          child: Text(
                            'Welcome to Startup Names Generator, please login below',
                          )),
                      Container(
                        padding: EdgeInsets.all(10),
                        child: TextField(
                          controller: _email,
                          decoration: InputDecoration(
                            labelText: 'Email',
                          ),
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(10),
                        child: TextField(
                          controller: _password,
                          decoration: InputDecoration(
                            labelText: 'Password',
                          ),
                        ),
                      ),
                      Container(
                        //height: 50,
                        //padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                          child: RaisedButton(
                            textColor: Colors.white,
                            color: Colors.red,
                            child: Text('Log in'),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.all(Radius.circular(16.0))),
                            onPressed: () async{
                              if (!await user.signIn(
                                _email.text, _password.text))
                                Scaffold.of(context).showSnackBar(new SnackBar(
                                    content: new Text('There was an error logging into the app')));


                              else {
                                //form.save();
                                //Navigator.popUntil(context, ModalRoute.withName('/'));
                                Navigator.push(context,
                                    MaterialPageRoute(builder: (context) =>
                                        profile_page(saved: widget.saved, email: this._email.text.toString())));
                              }
                            },
                          )
                      ),
                    ]
                ),
              )
      ),
    );
  }
}
